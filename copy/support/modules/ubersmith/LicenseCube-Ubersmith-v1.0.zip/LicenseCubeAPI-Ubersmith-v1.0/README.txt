LicenseCube Ubersmith Provisioning Module

The LicenseCube Provisioning Modules for Ubersmith, allows you to provision any of the licenses available from LicenseCube.com by means of it's API.

They are 2 modules: an order module and a service module.  A third file is required for comunicating with the LicenseCube API.

These modules are installed just like any other Ubersmith modules, by simply copying the files inside the Ubersmith installation.

In order to set them up, you'll need an active LicenseCube API account.

Prerequisites:
==============
 - An active LicenseCube API account (client id and password is required).
 - Your public IP address has to be enabled on LicenseCube.

Installation:
=============
Copy all files from the "install" subdirectory to your Ubersmith installation root directory, while keeping the folder structure intact.

Configuration:
=============

Service Module:
--------------
Create a new Service Plan, and add the "LicenseCube Service Module" to it.
Remember to setup the module's configuration.

Order Module:
------------
Select an Order Queue (perhaps a brand new one at first, for testing purposes), and add a new action, select the 'LicenseCube Order Module', and setup the module's configuration.


In both modules, you need to fill in the "API User" and "API Password" fields.  The "Dry-run" option will let you run the module in a "test mode" and will actually not create any license, but operate just as in live mode, allowing you to try it's functionality without using your account credits or charging your credit card.

Click on the "Save" button to finish the module configuration.

(c)2011 LicenseCube. All rights reserved.

