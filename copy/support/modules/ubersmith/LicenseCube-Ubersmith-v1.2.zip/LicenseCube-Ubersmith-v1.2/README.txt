LicenseCube Ubersmith Provisioning Module

The LicenseCube Provisioning Modules for Ubersmith, allows you to provision
any of the licenses available from LicenseCube.com by means of it's API.

They are 2 modules: an order module and a service module.  A third file is
required for comunicating with the LicenseCube API.

These modules are installed just like any other Ubersmith modules, by simply
copying the files inside the Ubersmith installation.

In order to set them up, you'll need an active LicenseCube API account.

Prerequisites:
==============
 - An active LicenseCube API account (client id and password is required).
 - Your public IP address has to be enabled on LicenseCube.

Installation:
=============
Copy all files from the "install" subdirectory to your Ubersmith installation
root directory, while keeping the folder structure intact.

Configuration:
=============

Service Module:
--------------
Create a new Service Plan, and add the "LicenseCube Service Module" to it.

Module configuration:
 * API User ID: this is a small number.

 * API Password: the password you should have received by e-mail.

 * Dry-run: check that if you want to use the module for testing, while not any
   real license will be provisioned.

 * E-mail notifications: if checked, you'll get email notifications on licensing
   operations.

 * Auto Update: if checked, all the service plan options will be created if
   missing; and their pricing updated if already existing.
   If you select only 1 license (see "License" option below) for this service
   plan, then the plan pricing will be overriden for all of the periods
   available in the system.

 * Currency: a best guess is attempted against the currency symbol you selected
   on the global configuration.  But it's possible that this guess is not right
   at all, so you can change this currency.  It's used for translating the
   price from LicenseCube to your local currency.  Consider that the rate
   conversion we apply may not be exactly the same as yours, so some small
   difference may come up.  Review the pricing carefully.

 * License: you can select to support any single possible license LicenseCube
   offers on this service plan, or you can just support one license per service
   plan.


The simplest setup is:
1) one service plan for each license your system will be using
2) packs of that plan should represent only licenses; not any other service
   (say hosting).


Order Module:
------------
Select an Order Queue (perhaps a brand new one at first, for testing purposes),
and add a new action, select the 'LicenseCube Provisioning' module, and select
which pack(s) need to be processed.

Click on the "Save" button to finish the module configuration.

Notes:
1) the LicenseCube order module need to be setup in the order queue after the
   'Add Services' module, or it will fail to work.

(c)2011 LicenseCube. All rights reserved.

