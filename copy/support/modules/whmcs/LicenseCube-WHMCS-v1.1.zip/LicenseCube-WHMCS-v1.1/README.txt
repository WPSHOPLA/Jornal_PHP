LicenseCube WHMCS Provisioning Module

The LicenseCube Provisioning Module for WHMCS (also referred to as Product or Server Module), allows you to provision any of the licenses available from LicenseCube.com to a new product/service created in that popular hosting billing system.

The LicenseCube Provisioning Module installs and configures just like any WHMCS server module, but requires an active LicenseCube API account, the LicenseCube API client class (included in the package) and a working installation of WHMCS. Further system requirements are covered with those of WHMCS.

Prerequisites:
==============
 - LicenseCube API account must be configured in the module
 - UTF-8 is required as WHMCS system charset

Installation:
=============
Copy all files from the "install" subdirectory to your WHMCS installation root directory, while keeping the folder structure intact.

Configuration:
=============
Create a new product/service or go to the page of an existing service plan in your WHMCS "Setup" > "Products/Service" option.

Go to the "Module Settings" tab and on the "Module Name" selection dropdown select "Licensecube", if you cannot see the "Licensecube" option, the server modules files were not installed correctly.

Proceed to complete your LicenseCube API account credentials in the "API User" and "API Password" fields. The "Dry-run" option will let you run the server module in a "test mode" and will actually not create any license, but operate just as in live mode, allowing you to try it's functionality without using your account credits or charging your credit card.

Click on the "Save Changes" button to finish the LicenseCube server module configuration.
Note that you also need to select the "Licenses by LicenseCube - Licenses provided by LicenseCube" on the "Configurable Options" tab to assign that Option Group to the module. This will be later needed for selecting the license associated with your new product/services.

(c)2011 LicenseCube. All rights reserved.
