LicenseCube WHMCS Provisioning Module
=====================================

The LicenseCube Provisioning Module for WHMCS (also referred to as Product or
Server Module), allows you to provision any of the licenses available from
LicenseCube.com to a new product/service created in that popular hosting
billing system.

The LicenseCube Provisioning Module installs and configures just like any WHMCS
server module, but requires an active LicenseCube API account and a working
installation of WHMCS. Further system requirements are covered with those of WHMCS.

Prerequisites:
==============
 - LicenseCube API account (user and password) must be configured in the module
 - UTF-8 is required as WHMCS system charset

Installation:
=============
Copy all files from the "install" subdirectory to your WHMCS installation root
directory, while keeping the folder structure intact.

Configuration:
=============
Create a new product/service or go to the page of an existing service plan in
your WHMCS "Setup" > "Products/Service" option.

Go to the "Module Settings" tab and on the "Module Name" selection dropdown
select "Licensecube", if you cannot see the "Licensecube" option, the server
modules files were not installed correctly.

Proceed to complete the fields:
 - "API User": it's your LicenseCube API account userid (a positive number).
 - "API Password": it's your LicenseCube API password.
 - "Dry-run": let you run the module in a "test mode" and will actually not
   provision any license, but operate just as in live mode, allowing you to
   check it's functionality without using your account credits or charging
   your credit card.
 - "Non-suspendable": let you list the licenses that will not be suspended
   on LicenseCube.com when the service is suspended on your WHMCS system.
   Most of the times, this can be left empty (the default).
 - "License": it's the license you wish to attach to this service.
 - "Product Update": if checked, your product pricing and options will be
   updated every time you hit 'Save Changes'.  Be carefull if you have:
   o multiple currencies, or
   o one currency which is not USD.

Click on the "Save Changes" button to finish the LicenseCube server module
configuration.

You should check also for the "Configurable Options" attached to this product,
to see if you are intersted in offering all of the possible variatons.  Most
of the time, you'll not need to change anything.

Multiple Currencies and Non USD currency:
========================================

Every time the module updates the pricing and options for a license, it also
updates the pricing.  If you have any non-USD currency enabled, all the prices
will be converted using LicenseCube's rate conversion.

Keep in mind that the rate conversion that your WHMCS system will use will not
be exactly the same as LicenseCube's.  So, in general; you may want to double
check the pricing if you have any non-USD currency enabled.

The rate conversion is done based on the "Currency Code".  In the file called
"Currencies.txt" you will find the list of currencies supported.

(c)2011 LicenseCube. All rights reserved.
