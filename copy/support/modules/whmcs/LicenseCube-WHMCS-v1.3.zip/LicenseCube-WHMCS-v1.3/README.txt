
LicenseCube WHMCS Provisioning Module
=====================================

The LicenseCube Provisioning Module for WHMCS (also referred to as Addon
Module), allows you to provision any of the licenses available from
LicenseCube.com to a new product created in the popular hosting billing
system.

The LicenseCube Provisioning Module installs and configures just like any WHMCS
addon module, but requires an active LicenseCube API account and a working
installation of WHMCS. Further system requirements are covered with those of WHMCS.

Prerequisites:
==============
 - LicenseCube API account (user and password) must be configured in the module
 - UTF-8 is required as WHMCS system charset

Installation:
=============
Copy all files from the "whmcs" subdirectory to your WHMCS installation root
directory, while keeping the folder structure intact.

Configuration:
=============

Please, refer to our online guide:

http://kbase.licensecube.com/sales-faqs/licensecube-whmcs-module-documentation.html

(c)2012 LicenseCube. All rights reserved.

